package com.example.magicmeals202

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
